const games = {
  action: ["Free Fire", "Call of Duty", "Fortnite"],
  puzzle: ["Candy Crush", "Sudoku"],
  adventure: ["Minecraft", "Zelda"]
};

function suggestGame() {
  const genre = document.getElementById("genre").value;
  const result = document.getElementById("result");
  if (games[genre]) {
    const randomGame = games[genre][Math.floor(Math.random() * games[genre].length)];
    result.innerHTML = `Try this game: <strong>${randomGame}</strong>`;
  } else {
    result.innerHTML = "Please select a genre.";
  }
}